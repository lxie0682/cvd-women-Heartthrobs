"""Independent check of the main results.

Recomputes the primary numbers with a different implementation from the notebooks (scikit-learn's logistic
regression and roc_auc_score instead of statsmodels and our rank-based AUC, and a separately written bootstrap)
and compares them with outputs/model_results.csv.

Run from anywhere inside the repository, after both notebooks:   python src/verify_results.py
"""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

SEED, TEAM = 2026, Path(__file__).resolve().parents[1]
RAW_NAME = "cardiovascular_dataset_OpenBio_Final.csv"
candidates = [p / "track-02" / "data" / RAW_NAME for p in TEAM.parents] + [TEAM.parent / "data" / RAW_NAME]
raw_path = next((p for p in candidates if p.is_file()), None)
if raw_path is None:
    sys.exit(f"{RAW_NAME} not found. Run this from inside the datathon repository.")
saved = pd.read_csv(TEAM / "outputs" / "model_results.csv").set_index("age_group")

# 1. Rebuild the cohort straight from the raw file.
d = pd.read_csv(raw_path, sep=";")
d = d[d["gender"] == 1].copy()
d["age_years"] = d["age"] / 365.25
d = d[(d["ap_hi"] >= 70) & (d["ap_hi"] <= 250) & (d["ap_lo"] >= 40) & (d["ap_lo"] <= 150) & (d["ap_hi"] > d["ap_lo"])].reset_index(drop=True)
d["age_group"] = np.select([d["age_years"] < 45, d["age_years"] < 56], ["Under 45", "45 to 55"], "56 and over")
d["chol2"], d["chol3"] = (d["cholesterol"] == 2).astype(int), (d["cholesterol"] == 3).astype(int)

checks = []
def check(name, got, want, tol):
    ok = abs(got - want) <= tol
    checks.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}: recomputed {got:.4f}, saved {want:.4f}")

print(f"Cohort rebuilt from raw: {len(d):,} records, {int(d['cardio'].sum()):,} CVD-positive")

# 2. Same split, different fitting library. A very weak penalty (C = 1e6) makes this effectively unpenalized.
dev, test = train_test_split(d, test_size=0.20, random_state=SEED, stratify=d["age_group"] + "_" + d["cardio"].astype(str))
def scores(cols):
    model = make_pipeline(StandardScaler(), LogisticRegression(C=1e6, max_iter=2000)).fit(dev[cols], dev["cardio"])
    return model.predict_proba(test[cols])[:, 1]
test = test.assign(a=scores(["age_years"]), b=scores(["age_years", "ap_hi", "chol2", "chol3"]))

check("Test-set size", len(test), saved.loc["All women", "n_test"], 0)
for g in ["Under 45", "45 to 55", "56 and over"]:
    t = test[test["age_group"] == g]
    a, b = roc_auc_score(t["cardio"], t["a"]), roc_auc_score(t["cardio"], t["b"])
    check(f"{g}: CVD-positive test records", int(t["cardio"].sum()), saved.loc[g, "n_positive"], 0)
    check(f"{g}: AUC, age alone", a, saved.loc[g, "auc_age"], 0.002)
    check(f"{g}: AUC, expanded", b, saved.loc[g, "auc_expanded"], 0.002)
    check(f"{g}: gain in AUC", b - a, saved.loc[g, "delta_auc"], 0.002)

# 3. A separately written paired bootstrap for one group (different random stream, so allow Monte Carlo error).
g = "56 and over"
t = test[test["age_group"] == g]
pos, neg = t[t["cardio"] == 1], t[t["cardio"] == 0]
rng = np.random.default_rng(7)
deltas = []
for _ in range(1000):
    s = pd.concat([pos.iloc[rng.integers(0, len(pos), len(pos))], neg.iloc[rng.integers(0, len(neg), len(neg))]])
    deltas.append(roc_auc_score(s["cardio"], s["b"]) - roc_auc_score(s["cardio"], s["a"]))
lo, hi = np.percentile(deltas, [2.5, 97.5])
check(f"{g}: lower 95% bound of gain", lo, saved.loc[g, "ci_lower"], 0.006)
check(f"{g}: upper 95% bound of gain", hi, saved.loc[g, "ci_upper"], 0.006)

print(f"\n{sum(checks)} of {len(checks)} checks passed.")
sys.exit(0 if all(checks) else 1)
