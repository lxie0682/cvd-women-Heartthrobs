# Team Heartthrobs: The Unseen Heart

**Beyond Age: Does the Added Value of Blood Pressure and Cholesterol Differ Across Women's Ages?**

OpenBio 2026 Datathon, Track 2: Cardiovascular Health in Women

> This project is a student data analysis. It is not medical advice, a diagnostic tool or clinical guidance.

![Headline visual: gain in AUC from adding blood pressure and cholesterol to age, by age group](figures/headline.png)

## Team

| Name | Role |
|---|---|
| [Add name] | [Data cleaning and modeling] |
| [Add name] | [Statistics and validation] |
| [Add name] | [Article and public health context] |
| [Add name] | [Presentation and clinical interpretation] |

## Research Question

Among records coded as women in the OpenBio Cardiovascular Disease Dataset, how much does adding systolic blood pressure and cholesterol improve discrimination of recorded CVD beyond age alone, and how does this improvement differ across predefined age groups?

This adapts starter question 3 ("Do cholesterol and glucose levels add information beyond blood pressure and age?") into a comparison across age groups.

## Datasets Used

- [x] Dataset 1: Cardiovascular Disease Dataset
- [ ] Dataset 2: Heart Attack Risk Prediction Dataset (synthetic)
- [ ] Dataset 3: Global CVD in Women, Tables S1 and S2

We use Dataset 1 only. Dataset 2 is synthetic and cannot serve as evidence about real women, and Dataset 3 describes countries, not individuals. Neither can answer a question about what an individual's exam measurements add.

## Key Findings

On 8,946 held-out records, adding systolic blood pressure and cholesterol to an age-only logistic model raised the AUC (how often a model ranks a record with a CVD label above one without; 0.5 is a coin flip):

| Age group | AUC, age alone | AUC, age + BP + cholesterol | Gain (95% CI) |
|---|---:|---:|---|
| Under 45 | 0.56 | 0.81 | **+0.26** (0.21 to 0.30) |
| 45 to 55 | 0.55 | 0.76 | **+0.22** (0.20 to 0.24) |
| 56 and over | 0.56 | 0.72 | **+0.16** (0.14 to 0.18) |
| All women | 0.64 | 0.78 | +0.14 (0.13 to 0.15) |

- **The gain was larger for younger women than for the oldest.** Under 45 minus 56 and over: +0.10 (95% CI 0.05 to 0.15). 45 to 55 minus 56 and over: +0.06 (0.03 to 0.08). The two younger groups did not clearly differ (+0.04, −0.01 to 0.09), so we do not claim a difference there.
- **Effect sizes.** Each 10 mmHg of systolic pressure went with 1.86 times the odds of a CVD label (95% CI 1.83 to 1.89) after accounting for age and cholesterol; cholesterol well above normal went with 2.71 times the odds (2.52 to 2.91). In an exploratory analysis the blood pressure odds ratio fell from 2.51 under 45 to 1.60 at 56 and over.
- **Checks.** The model is well calibrated across all women (slope 0.96) but too cautious for women under 45 (slope 1.52) and too bold for women 56 and over (slope 0.76). The main result held under five alternative cleaning rules, a flexible spline model, two other ways of cutting age, and 20 × 5-fold cross-validation.
- **What stays unseen.** At every age about 3 in 10 CVD-positive records had systolic pressure under 130 mmHg and normal cholesterol.

Every number is in [`docs/results_summary.md`](docs/results_summary.md), which the analysis notebook writes.

## Limitations

- **The outcome is a label recorded at the exam, not a future event.** Nothing here predicts who will develop heart disease.
- **The label is undocumented.** If it includes diagnoses such as hypertension, blood pressure partly measures the outcome and the AUCs overstate what it reveals about heart disease.
- **Association, not causation.** Treatment is not recorded and may weaken the blood pressure association in diagnosed women.
- **Age bands are not menopause stages.** The file has no menopause, pregnancy or hormone information.
- **Sex is recorded as one binary code.** Findings do not extend to people outside the two recorded categories.
- **Unknown sampling.** The file does not document where or how records were collected. About half of its records carry the label, far more than in any general population, and it covers ages 30 to 64 only.
- **Coarse measurements.** Cholesterol is three ordered categories; blood pressure is one reading, mostly rounded to 10.
- We did not use the synthetic Dataset 2 or the country-level Dataset 3, so the synthetic-data and ecological-fallacy cautions do not arise.

More detail: [`docs/limitations.md`](docs/limitations.md).

## How to Run

1. The raw files are already in `track-02/data/` (see the [data guide](../data/README.md)). On Colab the first notebook cell downloads them.
2. Install packages: `pip install -r requirements.txt`
3. Run `notebooks/01_cleaning.ipynb`, then `notebooks/02_analysis.ipynb`, top to bottom. Nothing needs to be filled in. Notebook 01 takes a few seconds and notebook 02 about one minute.
4. Optional: `python src/verify_results.py` recomputes the main numbers with a separate implementation and compares them with the saved results.

All random steps use seed 2026, so a rerun reproduces the reported numbers. If notebook 02 cannot find the cleaned file (for example in a fresh Colab session) it rebuilds it from the raw file with the same rules.

## Files

| Path | Contents |
|---|---|
| `notebooks/01_cleaning.ipynb` | Audits and cleans Dataset 1, writes the cleaning log |
| `notebooks/02_analysis.ipynb` | Summary statistics, models, confidence intervals, checks, figures, results summary and the optional Evidence Explorer |
| `src/verify_results.py` | Independent recomputation of the main results |
| `figures/headline.png` | **Headline visual** (same image as `04_incremental_auc.png`) |
| `figures/01` to `08` | Sample composition, CVD share by age, measurement associations, incremental AUC, calibration, regression forest plot, blood pressure by age, sensitivity analyses |
| `docs/article.md` | **Science communication article**, following the [HUDP article guide](../../docs/article-guide.md), with six graphs |
| `docs/cleaning_log.md` | **Cleaning log**: each rule, its reason and the records affected (written by notebook 01) |
| `docs/results_summary.md` | Every reported number (written by notebook 02) |
| `docs/research_protocol.md` | The analysis plan fixed before modeling, and what was added afterwards |
| `docs/limitations.md` | Responsible-use statement and full limitations |
| `docs/presentation-outline.md` | Five-minute presentation outline and script |
| `outputs/` | Result tables as CSV (written by notebook 02) |
| `requirements.txt` | Python packages |

## Presentation

Video link: [add your unlisted YouTube link]

Article: [`docs/article.md`](docs/article.md)

## Sources

- Ulianova S. Cardiovascular Disease dataset. Kaggle. Version 1, 2019. https://www.kaggle.com/datasets/sulianova/cardiovascular-disease-dataset
- Li Y, Yin N, Li C, Yang SW. Global burden of cardiovascular disease in women, 1990-2019. Medicine (Baltimore). 2025;104(27):e43215. https://pmc.ncbi.nlm.nih.gov/articles/PMC12237364/ (context only)
- Jin X, et al. Women's Participation in Cardiovascular Clinical Trials From 2010 to 2017. Circulation. 2020;141(7):540-548. https://doi.org/10.1161/CIRCULATIONAHA.119.043594
- Hayes SN, et al. Spontaneous Coronary Artery Dissection: Current State of the Science. Circulation. 2018;137(19):e523-e557. https://doi.org/10.1161/CIR.0000000000000564
- Harvard Undergraduate Data Project (HUDP). HUDP Article Guide (2025-2026). https://www.hudp.org/
- Tools: pandas, NumPy, SciPy, statsmodels, scikit-learn, matplotlib, ipywidgets
