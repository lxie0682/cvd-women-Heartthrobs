# Research Protocol: The Unseen Heart

OpenBio 2026 Datathon, Track 2 · Team Heartthrobs

> This project is a student data analysis. It is not medical advice, a diagnostic tool or clinical guidance.

This is the analysis plan. Sections 1 to 12 were fixed before any model was fitted. Section 13 lists, openly, what was decided or added after looking at data.

## 1. Primary research question

Among records coded as women in the OpenBio Cardiovascular Disease Dataset, how much does adding systolic blood pressure and cholesterol improve discrimination of recorded CVD beyond age alone, and how does this improvement differ across predefined age groups?

## 2. Why it matters

Age dominates cardiovascular risk scores, so overall model performance can hide how much routine measurements tell us about women of similar age. Heart disease in younger women is often under-recognized. Knowing at which ages routine measurements are most and least informative is a small, checkable piece of that problem.

## 3. Dataset and study population

Dataset 1 (Cardiovascular Disease Dataset; 70,000 exam records). Population: records with `gender` = 1 (coded as women), after the cleaning rules in `cleaning_log.md`. Datasets 2 and 3 are not used.

## 4. Outcome

`cardio`: a CVD label (0 or 1) recorded at the exam. It is not a future event and its definition is not documented by the source.

## 5. Age groups

| Group | Rule |
|---|---|
| Under 45 | age_years < 45 |
| 45 to 55 | 45 ≤ age_years < 56 |
| 56 and over | age_years ≥ 56 |

Age is converted from days (`age / 365.25`) and not rounded. The groups are age bands. They are not premenopausal, perimenopausal or postmenopausal groups; the file has no menopause variable.

## 6. Predictors

- **Primary:** age in years (continuous), systolic blood pressure `ap_hi` (continuous, mmHg), cholesterol (three categories, level 1 as reference; categorical so that the step from 1 to 2 need not equal the step from 2 to 3).
- **Exploratory only:** diastolic pressure, glucose, smoking, alcohol, activity, weight. These are not added to the primary model to raise its score.

## 7. Cleaning criteria

Chosen from the raw distributions before modeling, each with a one-sentence physical justification: systolic 70 to 250 mmHg, diastolic 40 to 150 mmHg, systolic > diastolic. Impossible values are removed, not repaired. Height and weight are flagged, not removed, because the primary models do not use them. Every rule is logged with its count.

## 8. Models

- **Model A (baseline):** `cardio ~ age_years`
- **Model B (expanded):** `cardio ~ age_years + ap_hi + C(cholesterol)`

Unpenalized logistic regression. Each model is fitted once on the whole development set and then evaluated within each age group. Separate models per age group are not used for the primary comparison.

## 9. Train and test strategy

80% development, 20% held-out test. Random, seed 2026, stratified by age group × CVD label. Both models use the same split. The test set is used once, for evaluation, and never to choose a model.

## 10. Primary measure

Gain in ROC-AUC, Model B minus Model A, within each age group on the held-out set. Key comparison: the difference in gain between age groups.

## 11. Uncertainty

Paired, stratified bootstrap on the test set: 2,000 resamples, resampling with replacement within each age group × label cell, keeping both models' scores attached to each record. 95% percentile intervals. Differences between age groups get their own intervals; we do not compare groups by whether separate intervals overlap.

## 12. Planned secondary and sensitivity analyses

- Overall AUC for both models.
- Calibration: plot, Brier score, slope and intercept, overall and by age group.
- Nonlinearity: natural cubic splines for age (both models) and blood pressure.
- Alternative cleaning rules: stricter and looser blood pressure ranges; repeated rows removed.
- Exploratory: CVD-positive records in the lowest quarter of Model B scores, described without calling them missed diagnoses.
- Adjusted odds ratios with 95% confidence intervals (age per 5 years, blood pressure per 10 mmHg).

## Hypotheses

- **H1:** Model B discriminates better than Model A.
- **H2:** The gain may differ across age groups. No direction was assumed.
- **H3 (exploratory):** Some CVD-positive records receive low scores.

## 13. Decided or added after looking at data

Nothing in sections 1 to 12 was changed. These were added, and each is labeled where it appears:

| Addition | When and why | Status |
|---|---|---|
| Exact blood pressure ranges (70 to 250, 40 to 150) | After auditing raw distributions, before any model | Primary rule |
| "Repair instead of remove" and "implausible height or weight removed" cleaning variants | Extra challenges to the cleaning choice | Sensitivity |
| 20 × 5-fold cross-validation | To check the result does not depend on one split | Sensitivity |
| Five-year bands and equal-sized thirds | To check the result does not depend on our cut points | Sensitivity |
| Single-measurement models and an "everything recorded" model | To see which measurement carries the gain | Exploratory |
| Odds ratios fitted within each age group, with an interaction test | Added after the calibration check showed the model fits age groups differently | Exploratory |
| Share of CVD-positive records with systolic pressure under 130 and normal cholesterol | A model-free version of H3 | Exploratory |
| Contrast in Model B's AUC between groups, alongside the contrast in gain | The baseline AUC is nearly equal across groups, so both are informative | Secondary |

## Known limitations

See `limitations.md`.

## Changes to this protocol

Changes to sections 1 to 12 require agreement from the whole team and an entry in section 13. Approving team member: [add name].
