# Presentation Outline and Script: The Unseen Heart

Five minutes at most. Every team member appears or speaks at least once. Upload the recording to YouTube as an unlisted video and paste the link into the README.

> Say on camera and show on a slide: "This is a student data analysis. It is not medical advice or a diagnostic tool."

Six slides. The script below is about 640 words, which is roughly 4 minutes 40 seconds at a calm pace. Speaker labels are suggestions for a four-person team; with three people, Speaker 4's part goes to Speaker 1.

## Introduction (0:00 to 0:45) · Slide 1: "The Unseen Heart" · Speaker 1

- **Research question:** Among women's exam records, how much do systolic blood pressure and cholesterol improve our ability to tell records with a CVD label from records without one, beyond age alone, and does that differ by age group?
- **Why it matters for women's cardiovascular health:** CVD is a leading cause of death for women, women were 38% of participants in recent cardiovascular trials, and heart disease in younger women is often under-recognized. Age makes any model look good, which can hide what routine measurements add for women of the same age.
- **Datasets used:** Dataset 1 only (real exam records). Not Dataset 2 (synthetic) or Dataset 3 (countries, not individuals).

> **Script.** "Two women walk into a routine exam. Each gets a blood pressure reading and a cholesterol test. One of them has cardiovascular disease. How much do those numbers help tell them apart? Age is the strongest signal of heart disease, so any model that knows age looks clever. We asked the harder question: once you know a woman's age, what do blood pressure and cholesterol add, and is it the same at 40 as at 60? We used Dataset 1, real exam records, because the synthetic and country-level datasets cannot answer a question about individual women. This is a student analysis, not medical advice."

## Methodology (0:45 to 1:45) · Slide 2: "One Dataset. Two Models." · Speaker 2

- **Cleaning decisions (from `cleaning_log.md`):** 70,000 records → 45,530 coded as women → 44,727 after removing 803 (1.8%) with impossible blood pressure: systolic outside 70 to 250, diastolic outside 40 to 150, or systolic not above diastolic. We removed typing errors instead of guessing repairs, and kept rare-but-real high readings. Height and weight were flagged, not removed.
- **Variables used or created, and how they were encoded:** age converted from days to years, not rounded; systolic pressure in mmHg; cholesterol as three ordered categories; three age groups fixed in advance (under 45, 45 to 55, 56 and over), which are age bands and not menopause stages.
- **Method and why we chose it:** two logistic regressions (yes-or-no outcome, transparent, gives odds ratios). Model A: age alone. Model B: age + systolic pressure + cholesterol. The measure is the gain in AUC within each age group.
- **How we checked our work:** 20% of records held out; 2,000 paired bootstrap resamples for 95% confidence intervals; direct intervals for differences between groups; calibration; five alternative cleaning rules; a flexible spline model; other age cut points; 20 × 5-fold cross-validation; an independent recomputation script.

> **Script.** "We started with 70,000 records and kept the 45,530 coded as women. We removed 803 with impossible blood pressure, like a top number of 12 or a bottom number of 1,000, and logged every rule with its count. That left 44,727. We fixed our plan before fitting anything: three age groups, and two logistic regression models. Model A knows only age. Model B adds systolic blood pressure and cholesterol. We built both on 80% of the records and tested them on the 20% they had never seen. Our measure is the AUC: take one record with a CVD label and one without, and ask how often the model scores the labeled one higher. A coin flip gets 0.5. We estimated uncertainty with 2,000 bootstrap resamples."

## Results (1:45 to 3:45) · Slides 3 and 4 · Speaker 3

**Slide 3: "Who Is in the Data?"** (show `02_cvd_by_age.png` and `03_measurement_associations.png`)

- **Sample size after cleaning:** 44,727 women; 6,263 under 45, 21,091 at 45 to 55, 17,373 at 56 and over. Test set 8,946.
- **Key summary statistics:** 49% of records carry a CVD label; the share rises from 22% under 40 to 68% at 60 to 64. Under 120 mmHg, 11% of the youngest and 38% of the oldest carry the label; from 140 mmHg up it is 82% to 87% at every age.

**Slide 4: "Beyond Age"** (show `headline.png` full screen, then `06_regression_forest.png`)

- **Headline visual:** gain in AUC +0.26 under 45 (95% CI 0.21 to 0.30), +0.22 at 45 to 55 (0.20 to 0.24), +0.16 at 56 and over (0.14 to 0.18).
- **Model metrics (AUC):** age alone 0.55 to 0.56 within each group; expanded model 0.81, 0.76 and 0.72. All women: 0.64 → 0.78.
- **Difference between groups:** under 45 vs 56 and over +0.10 (0.05 to 0.15); 45 to 55 vs 56 and over +0.06 (0.03 to 0.08); the two younger groups +0.04 (−0.01 to 0.09), not a clear difference.
- **Regression graph and effect sizes with 95% confidence intervals:** odds ratio per 10 mmHg systolic 1.86 (1.83 to 1.89); cholesterol well above normal 2.71 (2.52 to 2.91); above normal 1.46 (1.37 to 1.56); age per 5 years 1.32 (1.30 to 1.34). Exploratory by age: blood pressure odds ratio 2.51, 1.99, 1.60.

> **Script.** "The share of records with a CVD label triples across the age range, from 22% under 40 to 68% in the early sixties. That is why age alone looks powerful. But look at blood pressure. Under 120, 11% of the youngest women's records carry the label, against 38% of the oldest. Above 140, it is about 85% at every age. At high blood pressure age hardly matters; at normal blood pressure it matters a lot.
>
> Here is our headline. Within an age group, age alone is close to a coin flip, about 0.55. Adding blood pressure and cholesterol lifts the AUC to 0.81 for women under 45, 0.76 at 45 to 55, and 0.72 at 56 and over. The gain is 0.26, 0.22 and 0.16. Is that difference real? We tested the difference directly: the gain under 45 exceeds the gain at 56 and over by 0.10, with a 95% confidence interval from 0.05 to 0.15. Between the two younger groups the interval includes zero, so we do not claim a difference there.
>
> The regression graph tells the same story. Each 10 points of systolic pressure goes with 1.86 times the odds of a CVD label, interval 1.83 to 1.89, after accounting for age and cholesterol. Split by age, that odds ratio falls from 2.5 in the youngest women to 1.6 in the oldest."

## Discussion (3:45 to 5:00) · Slides 5 and 6 · Speaker 4

**Slide 5: "What Remains Unseen?"** (show `05_calibration.png` and `08_sensitivity.png`)

- **What the findings mean for women's cardiovascular health:** routine measurements carried the most information about a CVD label in younger women and the least in the oldest. One model for all ages was well calibrated on average (slope 0.96) but too cautious for women under 45 (slope 1.52) and too bold at 56 and over (slope 0.76): a score can be right on average and wrong for a group. And at every age about 3 in 10 labeled records had systolic pressure under 130 and normal cholesterol.
- **Limitations:** the outcome is a label recorded at the exam, not a future event, and its definition is undocumented, so blood pressure may partly measure the outcome; associations are not causes; treatment is not recorded; age bands are not menopause stages; sex is a single binary code; the sampling is unknown.

**Slide 6: "The Answer."**

- **What we would do with more time or resources:** repeat this in data with a documented outcome and follow-up; add treatment, menopause and pregnancy history; test a model that lets blood pressure count differently by age, checking calibration group by group.
- **Not-medical-advice statement:** "This is a student data analysis. It is not medical advice, a diagnostic tool or clinical guidance."

> **Script.** "We tried to break this result. Five other cleaning rules, a more flexible model, other age cut-offs, and cross-validation on every record. The ordering never changed. One check did surprise us: our model is well calibrated across all women, but its scores are too cautious for younger women and too bold for older ones. A score can be right on average and wrong for a group.
>
> And here is the unseen part. At every age, about 3 in 10 records with a CVD label had normal cholesterol and a systolic pressure under 130. On these two numbers they look unremarkable.
>
> Our limits matter. The outcome is a label recorded at the same exam, not a future event, and the dataset never defines it. If it includes high blood pressure itself, our numbers overstate what blood pressure reveals. These are associations, not causes. Age groups are not menopause stages, and sex is recorded as a single binary code. With more time, we would test this in data with a documented outcome and follow-up, and with treatment and menopause history.
>
> So, the answer: blood pressure and cholesterol told us more about recorded heart disease in younger women than in the oldest, and for about 3 in 10 labeled records at every age they said very little. Thank you."

## Final Slide

- Team Heartthrobs: [add names]
- Data: Ulianova S. Cardiovascular Disease dataset. Kaggle, 2019, via the OpenBio 2026 Datathon repository.
- Cited: Li et al., Medicine (2025); Jin et al., Circulation (2020); Hayes et al., Circulation (2018).
- Repository: https://github.com/lxie0682/cvd-women-Heartthrobs
- "This is a student data analysis. It is not medical advice, a diagnostic tool or clinical guidance."

## Before recording

- [ ] Headline figure fills the slide and is readable at 1080p.
- [ ] Every team member speaks or appears.
- [ ] Total time under 5:00 on a full run-through.
- [ ] No sentence says "predicts", "causes", "accuracy" or "missed diagnosis".
- [ ] Uploaded as **Unlisted** (not Private); link opened in a private browser window; link pasted into `README.md`.
