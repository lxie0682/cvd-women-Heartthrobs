# Cleaning Log

Written by `notebooks/01_cleaning.ipynb`. Rerun the notebook to update it. Every count comes from the code, none is typed by hand.

> This project is a student data analysis. It is not medical advice, a diagnostic tool or clinical guidance.

## Summary

- Raw file: **70,000** records, 13 columns, no missing values, no duplicate ids.
- Records coded as women (`gender` = 1): **45,530**, matching the organizers' reference count.
- Removed by the blood pressure rules: **803** records (1.8% of women).
- Final analysis sample: **44,727** records, of which **22,011** are labeled CVD-positive and **22,716** CVD-negative.

## Rules, in the order applied

Counts are sequential: a record removed by one rule is not counted again by a later rule. **Action** says whether a rule removes rows, derives a new column, or flags rows that are kept.

| Dataset | Rule | Action | Reason | Records before | Records after | Records affected |
|---|---|---|---|---:|---:|---:|
| D1 | Drop duplicate ids | remove | Each exam record should appear once | 70,000 | 70,000 | 0 |
| D1 | Convert age from days to years (new column age_years = age / 365.25) | derive | Age is stored in days; the original column is kept | 70,000 | 70,000 | 70,000 |
| D1 | Keep records coded as women (gender = 1) | remove | Our question is about women; code 1 is the shorter group and matches the organizers' count | 70,000 | 45,530 | 24,470 |
| D1 | Keep ap_hi between 70 and 250 mmHg | remove | Below 70 mmHg is shock, not a routine exam; no record lies between 240 and 309, so higher values are typing errors | 45,530 | 45,379 | 151 |
| D1 | Keep ap_lo between 40 and 150 mmHg | remove | Outside the range seen in ambulatory adults; values beyond are mostly 0, 1000 or 1100 | 45,379 | 44,775 | 604 |
| D1 | Keep rows where systolic > diastolic | remove | Systolic is always higher than diastolic | 44,775 | 44,727 | 48 |
| D1 | Keep rows where cardio is one of [0, 1] | remove | Outcome must be 0 or 1 | 44,727 | 44,727 | 0 |
| D1 | Keep rows where cholesterol is one of [1, 2, 3] | remove | Data dictionary lists levels 1, 2 and 3 only | 44,727 | 44,727 | 0 |
| D1 | Keep rows where gluc is one of [1, 2, 3] | remove | Data dictionary lists levels 1, 2 and 3 only | 44,727 | 44,727 | 0 |
| D1 | Keep adults aged 18 to 100 | remove | Guards against a mis-converted age; the youngest record is 29.7 years | 44,727 | 44,727 | 0 |
| D1 | Flag height outside 120 to 210 cm or weight outside 30 to 200 kg (body_plausible = 0) | flag | Not used in the main models, so the rows are kept; BMI is left empty for them | 44,727 | 44,727 | 37 |
| D1 | Flag rows identical to an earlier row in every column except id (repeat_profile = 1) | flag | Cannot tell a true duplicate from two women with the same coarse measurements; removal is tested in notebook 02 | 44,727 | 44,727 | 21 |
| D1 | Assign prespecified age groups: under 45, 45 to 55, 56 and over (new column age_group) | derive | Groups were fixed in the research protocol before any model was fitted | 44,727 | 44,727 | 44,727 |

## Records breaking each blood pressure rule, counted alone

A record can break more than one rule, so these do not add up to the sequential counts above.

| Problem | Records |
|---|---:|
| systolic outside 70 to 250 | 151 |
| diastolic outside 40 to 150 | 615 |
| systolic not above diastolic | 738 |
| at least one of the three | 803 |

## Who the rules removed

| Age group | Women before | Removed | Removed % |
|---|---:|---:|---:|
| Under 45 | 6,367 | 104 | 1.63 |
| 45 to 55 | 21,447 | 356 | 1.66 |
| 56 and over | 17,716 | 343 | 1.94 |

Of the removed records, 75.3% were labeled CVD-positive, compared with 49.2% of kept records. Removing them therefore takes out more positive records than negative ones. The effect on the sample is small because few records are removed, and notebook 02 tests whether stricter rules, looser rules or repairing the typing errors instead of removing them changes the main result.

## Decisions that are not removals

- **Missing values:** none in the file, so nothing was imputed.
- **Height and weight:** flagged, not removed, because the main models do not use them. BMI is empty for flagged rows.
- **Repeated rows:** flagged, not removed. Identical measurements under different ids may be two different women.
- **Cholesterol and glucose:** kept as ordered categories (1, 2, 3), never treated as measurements.
- **Age groups:** fixed bands of age. They are not menopause stages; the file has no menopause variable.
- **Original columns:** all kept. New information is added as new columns.
