# The Unseen Heart: What Age Alone Cannot Tell Us

**In 44,727 exam records from women, blood pressure and cholesterol said the most about who carried a heart disease label among the youngest women and the least among the oldest. At every age, about 3 in 10 labeled records looked unremarkable on both.**

By Team Heartthrobs: [add each team member's name]

> This article is a student data analysis for the OpenBio 2026 Datathon. It is not medical advice, a diagnostic tool or clinical guidance.

![Dot plot with one row per age group. In each row a coral circle marks the age-only model's score and a teal diamond marks the score after adding blood pressure and cholesterol. The gap is widest for women under 45 and narrowest for women 56 and over.](../figures/headline.png)

*Figure 1. How well two models separate exam records with and without a cardiovascular disease label, by age group. The coral circle is a model that knows only a woman's age. The teal diamond is a model that also knows her systolic blood pressure and cholesterol category. A score of 0.5 is a coin flip and 1.0 is perfect. The gain is +0.26 under 45, +0.22 at 45 to 55 and +0.16 at 56 and over. Bars are 95% confidence intervals from 2,000 bootstrap resamples of 8,946 records the models never saw.*

## Introduction

Picture two women at a routine exam. A nurse wraps a cuff around each woman's arm and writes down two numbers. A blood sample goes to the lab for cholesterol. Now suppose one of the women has cardiovascular disease (CVD), meaning disease of the heart and blood vessels, and the other does not. How much do those routine numbers help tell them apart?

The usual answer is "quite a lot", but that answer hides something. Age is the strongest single signal of heart disease, so any tool that knows a woman's age already looks clever. The harder and more useful question is what the measurements add once age is known, and whether they add the same amount for a woman of 40 as for a woman of 60.

That question matters for women in particular. CVD is a leading cause of death for women, with an estimated 27.6 million new cases among women worldwide in 2019 ([Li et al., 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC12237364/)). Yet women made up only 38% of participants in 740 cardiovascular trials completed between 2010 and 2017 ([Jin et al., 2020](https://doi.org/10.1161/CIRCULATIONAHA.119.043594)), and heart disease in younger women is often under-recognized. If routine measurements carry different amounts of information at different ages, that is worth knowing.

So we asked: **among women's exam records, how much do systolic blood pressure and cholesterol improve our ability to tell records with a CVD label from records without one, beyond age alone, and does that improvement differ by age group?**

Here is what you are in for: one dataset, two simple models, three age groups, and an answer that is clear in one direction and humbling in another.

## The Data and Our Methods

We used the [Cardiovascular Disease Dataset](https://www.kaggle.com/datasets/sulianova/cardiovascular-disease-dataset) supplied by the datathon: 70,000 exam records, of which 45,530 are coded as women. After removing 803 records with impossible blood pressure readings (every rule and count is in our [cleaning log](cleaning_log.md)), 44,727 remained. We compared two logistic regression models, a standard method for yes-or-no outcomes: one using age alone, and one using age, systolic blood pressure (the top number of a reading) and cholesterol category. Both were built on 80% of the records and tested on the other 20%, split into three age groups we fixed in advance: under 45, 45 to 55, and 56 and over. Three limits apply to everything below. The "CVD" outcome is a label recorded at the same exam, not a future event, and the source does not say how it was assigned. The file does not say where or how the records were collected. And sex is recorded as one binary code. Our age groups are bands of age, not stages of menopause, which the file does not record.

## What We Found

### Age sets the backdrop

The older the women in the file, the more of their records carry a CVD label: about 2 in 10 under age 40, rising to nearly 7 in 10 at 60 to 64.

![Line chart of the share of records labeled with cardiovascular disease in six five-year age bands, rising from 22 percent under age 40 to 68 percent at ages 60 to 64.](../figures/02_cvd_by_age.png)

*Figure 2. Share of records labeled with CVD by age at the exam. Bars are 95% confidence intervals, the range of values consistent with the data; most are too narrow to see. This is the share in this dataset, where about half of all records carry the label, far more than in any general population. It is not the rate of CVD among women in any population.*

This is why age alone makes a model look capable. Across all women, a model that knows nothing but age ranks a labeled record above an unlabeled one 64% of the time. That measure is called the AUC: pick one record with the label and one without, at random, and the AUC is how often the model gives the higher score to the one with the label. A coin flip scores 0.5.

But compare women of similar age and the advantage vanishes. Inside each of our three age groups, the age-only model scores 0.55 to 0.56, barely better than a coin.

### The same blood pressure means something different at 40 and at 60

Before any modeling, the raw percentages already hint at the answer.

![Two line charts. On the left, the share of records labeled with cardiovascular disease rises with cholesterol category in all three age groups. On the right, it rises with systolic blood pressure, and the three age groups are far apart at low blood pressure but nearly identical above 140.](../figures/03_measurement_associations.png)

*Figure 3. Share of records labeled with CVD by cholesterol category (left) and systolic blood pressure band (right), for each age group. Bars are 95% confidence intervals. The blood pressure bands are for display only; our models use the measured value. These are associations in exam records and do not show that either measurement causes CVD.*

On the right-hand panel, look at where the three lines sit. At a systolic pressure under 120, 11% of records from women under 45 carry the label, against 38% for women 56 and over. From 140 upward the three lines meet: 82% to 87% at every age.

**At high blood pressure, age hardly matters. At normal blood pressure, it matters a lot.** For the youngest women, blood pressure sorts records cleanly into "rarely labeled" and "usually labeled". For the oldest, many records are labeled even when the reading is normal.

### The main result: the measurements add most where age says least

Figure 1 puts a number on it. Adding blood pressure and cholesterol lifts the AUC:

- from 0.56 to 0.81 for women under 45, a gain of 0.26 (95% confidence interval 0.21 to 0.30)
- from 0.55 to 0.76 for women 45 to 55, a gain of 0.22 (0.20 to 0.24)
- from 0.56 to 0.72 for women 56 and over, a gain of 0.16 (0.14 to 0.18)

A gain of 0.26 means that out of every 100 pairs of records, one labeled and one not, the model now ranks about 26 more in the right order.

Is the difference between age groups real, or could it be chance? Eyeballing three intervals is not a fair test, so we calculated the uncertainty of the *difference* itself. The gain is larger under 45 than at 56 and over (a difference of 0.10, 95% confidence interval 0.05 to 0.15), and larger at 45 to 55 than at 56 and over (0.06, interval 0.03 to 0.08). Between the two younger groups the difference is 0.04 with an interval from −0.01 to 0.09. That interval includes zero, so **we do not claim the two younger groups differ.**

Nearly all of the gain comes from blood pressure. Cholesterol on its own adds about 0.05. And when we gave the model everything else in the file (the bottom blood pressure number, glucose, smoking, alcohol, physical activity and weight) the AUC rose by less than 0.01 in every age group. Whatever would help tell older women's records apart is not among the recorded variables.

### A second way to see it: odds ratios

An AUC describes a whole model. An odds ratio describes one variable: how much the odds of carrying the label rise with it, holding the others fixed. An odds ratio of 1 means no association.

![Forest plot. The left panel shows odds ratios for all women: age per five years 1.32, systolic blood pressure per 10 millimeters of mercury 1.86, cholesterol above normal 1.46, cholesterol well above normal 2.71. The right panel shows that the odds ratios for blood pressure and cholesterol are largest for women under 45 and smallest for women 56 and over.](../figures/06_regression_forest.png)

*Figure 4. Odds ratios for a recorded CVD label from logistic regression on all 44,727 records, each adjusted for the other variables shown. Bars are 95% confidence intervals. Left: all women. Right: the same model fitted within each age group, an exploratory analysis we added after seeing the calibration result below. These are associations, not causal effects.*

Across all women, each additional 10 mmHg of systolic pressure went with 1.86 times the odds of a CVD label (95% confidence interval 1.83 to 1.89) after accounting for age and cholesterol. Cholesterol "well above normal" went with 2.71 times the odds (2.52 to 2.91) compared with normal.

Split by age, the blood pressure odds ratio was 2.51 under 45, 1.99 at 45 to 55 and 1.60 at 56 and over, and the three intervals do not overlap. It is the same finding in a different unit.

### An unexpected result: one model does not fit all ages

A good model should also be calibrated: of the records it scores at 30%, about 30% should carry the label.

![Two calibration plots. On the left, both models track the diagonal line of perfect agreement for all women. On the right, the expanded model's line is steeper than the diagonal for women under 45 and shallower for women 56 and over.](../figures/05_calibration.png)

*Figure 5. Calibration on held-out records. Records are sorted by model score and grouped; each point compares the average score with the share actually labeled. Points on the dashed line mean the scores are right. Left: both models, all women. Right: the expanded model within each age group. Bars are 95% confidence intervals. Agreement with a recorded label is not validation for predicting future disease.*

Across all women our model is well calibrated. Within age groups it is not. For women under 45 the scores are too cautious: records it scored around 60% carried the label about 85% of the time. For women 56 and over the scores are too bold.

We did not expect this, and it follows from the main finding. A single model assumes 10 mmHg means the same thing at every age, and the data say otherwise. **A score can be right on average and still be wrong for a particular group of women.** Anyone building a risk tool from data like these should check it group by group.

### Does the result survive other choices?

Every analysis involves judgment calls. We repeated ours with each call changed: stricter and looser blood pressure limits, repairing typing errors instead of removing those records, a more flexible model, and retesting on every record in turn (cross-validation).

![Dot plot with three panels, one per age group. Each row is an alternative version of the analysis. In every panel the points cluster around the primary estimate, with the gain highest under 45 and lowest at 56 and over.](../figures/08_sensitivity.png)

*Figure 6. The gain in AUC from adding blood pressure and cholesterol, under eight versions of the analysis. Bars are 95% confidence intervals; for cross-validation, the range across 20 repeats. The shaded band is the primary analysis's interval.*

The ordering never changed. Slicing age into five-year bands or equal-sized thirds gave the same pattern.

## Unanswered Questions

**The unseen part.** The measurements work best among younger women, yet at every age about 3 in 10 records with a CVD label had a systolic pressure under 130 and normal cholesterol (31% under 45, 30% at 45 to 55 and 27% at 56 and over). On the two numbers we studied, those records look unremarkable. Among women under 45, more than a third of labeled records (37%) landed in the bottom quarter of our model's scores. These are records the model ranks low, not "missed diagnoses", but they mark the edge of what routine numbers can see.

**Why is the signal weaker in older women?** The data cannot say. Here we are speculating. Women who already have a diagnosis may be taking medicine that lowers their blood pressure, which would blur the link, and treatment is not recorded. Heart disease also has more routes as people age, and two numbers may capture a smaller share of them.

**What is the label?** The source does not define "CVD". If it includes a diagnosis of high blood pressure, then blood pressure is partly measuring the outcome itself, and our AUCs overstate how much it reveals about heart disease. This is the biggest caveat on the *size* of our gains. We do not see how it would produce the *difference* between ages, but we cannot rule it out.

**What about the heart conditions these numbers were never going to catch?** Spontaneous coronary artery dissection, or SCAD, is a tear in the wall of a heart artery. The American Heart Association describes it as an important cause of heart attack, particularly among young women with few conventional risk factors ([Hayes et al., 2018](https://doi.org/10.1161/CIR.0000000000000564)). Our data cannot identify SCAD or any other specific condition, and we make no claim about it. We mention it because it shows why "normal numbers" and "healthy heart" are not the same statement.

**Menopause, pregnancy and time.** The file has no menopause status, no pregnancy history and no follow-up. We cannot say whether the age pattern is about hormones, about years lived, or about who ended up in the dataset.

## Conclusions, Limitations and Next Steps

**What the data showed.** In these records, knowing a woman's blood pressure and cholesterol improved a model's ability to pick out records with a CVD label at every age, and the improvement was larger for women under 56 than for women 56 and over. The associations were strongest in the youngest women. A single model for all ages was accurate on average but too cautious for younger women and too bold for older ones.

**Where that leaves our question.** The answer to "does the added value differ by age?" is yes, between the oldest group and the two younger ones. Between the two younger groups, our data are not precise enough to tell.

**Limitations.**

- The outcome is a label recorded at the exam. Nothing here predicts who will develop heart disease.
- We do not know how that label was assigned, or where, when and from whom the records were collected. About half of the records carry the label, far more than in any general population, and the file covers ages 30 to 64 only.
- These are associations, not causes. Treatment is not recorded.
- Age bands are not menopause stages.
- Sex is recorded as a single binary code, so the findings do not extend to people outside the two recorded categories.
- Cholesterol is three broad categories and blood pressure is a single reading, mostly rounded to the nearest 10.
- Our confidence intervals capture sampling uncertainty only, not the unknowns above.

**With more time or resources** we would test the finding in a dataset with a documented outcome and follow-up over time, so that "discriminating a label" could become "predicting an event". We would want treatment, menopause and pregnancy history. And we would build and test a model that lets blood pressure count differently at different ages, checking calibration in each group.

## Data and Code

- Repository: [github.com/lxie0682/cvd-women-Heartthrobs](https://github.com/lxie0682/cvd-women-Heartthrobs). Both notebooks run top to bottom and reproduce every number and figure here.
- Full numerical results: [results_summary.md](results_summary.md). Cleaning rules and counts: [cleaning_log.md](cleaning_log.md). Analysis plan: [research_protocol.md](research_protocol.md).
- Data: Ulianova S. [Cardiovascular Disease dataset](https://www.kaggle.com/datasets/sulianova/cardiovascular-disease-dataset). Kaggle, 2019, as distributed in the [OpenBio 2026 Datathon repository](https://github.com/Harvard-Undergraduate-OpenBio/openbio-datathon-2026). The records contain no names or other identifying details.
- Sources cited: Li Y, Yin N, Li C, Yang SW. [Global burden of cardiovascular disease in women, 1990-2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC12237364/). Medicine. 2025. Jin X, et al. [Women's Participation in Cardiovascular Clinical Trials From 2010 to 2017](https://doi.org/10.1161/CIRCULATIONAHA.119.043594). Circulation. 2020. Hayes SN, et al. [Spontaneous Coronary Artery Dissection: Current State of the Science](https://doi.org/10.1161/CIR.0000000000000564). Circulation. 2018.
- Tools: pandas, NumPy, statsmodels, scikit-learn, SciPy and matplotlib. All figures are our own.

## Acknowledgements

We thank the Harvard Undergraduate OpenBio organizers for the data package, starter notebooks and guidance, and the Harvard Undergraduate Data Project for the article guide this piece follows. [Add anyone else who supported the team, and note any AI tools used if the organizers ask for that.]

---

*This project is a student data analysis for the OpenBio 2026 Datathon. It is not medical advice, a diagnostic tool or clinical guidance.*
