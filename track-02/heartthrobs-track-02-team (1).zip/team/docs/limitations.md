# Limitations and Responsible Use

> This project is a student data analysis for the OpenBio 2026 Datathon. It is not medical advice, a diagnostic tool or clinical guidance. No one should use these results to judge their own or anyone else's health.

## How we address each Track 2 ground rule

| Ground rule | What we did |
|---|---|
| Correlation is not causation | We write "associated with" and "went with", never "causes". Odds ratios are described as adjusted associations. |
| Synthetic is not real | We did not use Dataset 2. |
| Countries are not individuals | We did not use Dataset 3 for analysis. One global figure from its source article is cited as background only. |
| Sex is recorded as binary | We write "records coded as women" where precision matters and do not generalize beyond the two recorded categories. |
| Not medical advice | Stated in the README, both notebooks, the article, every doc, the headline figure and the presentation. |
| Show uncertainty | Every estimate has a 95% confidence interval. Differences between groups have their own intervals. |
| Respect data licenses | Sources are cited. We redistribute no raw data; cleaned data are rebuilt by the notebook. |

## What our results cannot tell you

1. **Not prediction.** The CVD label was recorded at the same exam as the measurements. An AUC here is the ability to sort existing labels, not to foresee disease.
2. **An undocumented outcome.** The source does not define the label. If it includes diagnoses such as hypertension, blood pressure is partly measuring the outcome, and the AUC and odds ratios for blood pressure are inflated as statements about heart disease. About 5 in 6 records with systolic pressure of 140 or more carry the label at every age, which is consistent with that concern.
3. **Not causal.** Unrecorded factors, including treatment, could produce or hide associations. Medication that lowers blood pressure in diagnosed women would weaken the association, and could do so more at older ages.
4. **Not about menopause.** Age bands are age bands. No menopause, pregnancy or hormone information exists in the file.
5. **Not about any specific condition.** The label does not distinguish heart attack, stroke, heart failure or anything else. In particular the data cannot identify spontaneous coronary artery dissection (SCAD), and low-scored records are not stand-ins for it.
6. **Not representative.** The file does not say where, when or how records were collected. About half of its records carry the label, far more than in any general population, and it covers ages 30 to 64 only. Shares in our figures are shares of these records, not population rates.
7. **Not clinical performance.** AUC is not accuracy, sensitivity or specificity, and no decision threshold was studied.
8. **"Low-scored" is not "missed".** The lowest-quarter rule describes model errors. It is not a diagnostic threshold.

## Limits of the measurements

- Cholesterol and glucose are three ordered categories, not lab values.
- Blood pressure is a single reading, mostly rounded to the nearest 10 mmHg.
- Smoking, alcohol and activity are self-reported yes or no answers.
- 803 records (1.8% of women) had impossible blood pressure values and were removed. Removed records were more often CVD-positive (75%) than kept ones (49%). Sensitivity analyses that repair or keep more of them gave the same conclusion.

## Limits of the statistics

- Bootstrap confidence intervals reflect sampling variation in the test set only. They do not cover uncertainty about how the data were produced.
- The under-45 group is the smallest (1,253 test records, 349 CVD-positive), so its estimates are the least precise.
- The gain in AUC depends on the baseline. Within age groups the age-only AUC is nearly identical (0.55 to 0.56), so here the gain and the expanded model's AUC tell the same story, but that need not hold elsewhere.
- Analyses marked exploratory were not in the original plan and should be read as leads, not conclusions.
- The single model is miscalibrated within age groups (slope 1.52 under 45, 0.76 at 56 and over). Its scores should not be read as probabilities for a given woman.

## Sex and gender

The file holds one binary code, which the source calls gender and which we, following the organizers, interpret by the height check as female and male. It cannot represent intersex, transgender or nonbinary people, and we make no claims about them.
