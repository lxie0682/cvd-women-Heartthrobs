# Results Summary

Written by `notebooks/02_analysis.ipynb`. Rerun the notebook to update it. Every number comes from the code.

> This project is a student data analysis. It is not medical advice, a diagnostic tool or clinical guidance.

## Question

Among records coded as women in the OpenBio Cardiovascular Disease Dataset, how much does adding systolic blood pressure and cholesterol improve discrimination of recorded CVD beyond age alone, and how does this improvement differ across predefined age groups?

## Sample

- Cleaned cohort: **44,727** records coded as women, 22,011 labeled CVD-positive (49.2%).
- Development set: 35,781 records (80%). Held-out test set: 8,946 records (20%). Split stratified by age group and CVD label, seed 2026.

## Models

- Model A (baseline): `cardio ~ age_years`
- Model B (expanded, primary): `cardio ~ age_years + ap_hi + C(cholesterol)`
- Both are unpenalized logistic regressions fitted once on the development set and evaluated on the same held-out records.

## Primary result: gain in held-out AUC from adding systolic blood pressure and cholesterol

95% confidence intervals from 2,000 paired bootstrap resamples, stratified by age group and CVD label.

| Age group | Test records | CVD-positive | CVD-negative | AUC, age alone (95% CI) | AUC, expanded (95% CI) | Gain (95% CI) |
|---|---:|---:|---:|---|---|---|
| Under 45 | 1,253 | 349 | 904 | 0.555 (0.519 to 0.590) | 0.811 (0.782 to 0.838) | **+0.255** (0.213 to 0.299) |
| 45 to 55 | 4,218 | 1,897 | 2,321 | 0.546 (0.529 to 0.563) | 0.762 (0.748 to 0.776) | **+0.216** (0.196 to 0.235) |
| 56 and over | 3,475 | 2,157 | 1,318 | 0.564 (0.543 to 0.583) | 0.722 (0.705 to 0.739) | **+0.158** (0.137 to 0.180) |
| All women | 8,946 | 4,403 | 4,543 | 0.643 (0.638 to 0.647) | 0.783 (0.775 to 0.792) | **+0.140** (0.132 to 0.149) |

## Direct comparisons between age groups

A difference between two groups is supported only when the interval for the difference itself excludes zero.

| Quantity | Contrast | Difference (95% CI) | Interval excludes zero |
|---|---|---|---|
| Gain from adding measurements (delta AUC) | Under 45 minus 45 to 55 | +0.040 (-0.007 to 0.089) | no |
| Expanded model AUC | Under 45 minus 45 to 55 | +0.049 (0.016 to 0.080) | yes |
| Gain from adding measurements (delta AUC) | Under 45 minus 56 and over | +0.097 (0.051 to 0.147) | yes |
| Expanded model AUC | Under 45 minus 56 and over | +0.089 (0.055 to 0.123) | yes |
| Gain from adding measurements (delta AUC) | 45 to 55 minus 56 and over | +0.058 (0.029 to 0.085) | yes |
| Expanded model AUC | 45 to 55 minus 56 and over | +0.040 (0.018 to 0.062) | yes |

## Calibration on the held-out test set

A slope of 1 and an intercept of 0 mean scores agree with observed frequencies. The Brier score is the mean squared gap between score and label (lower is better; 0.25 is what a constant 50% score earns).

| Age group | Model | Brier score | Calibration slope | Calibration intercept |
|---|---|---:|---:|---:|
| Under 45 | Age alone | 0.200 | 1.45 | +0.03 |
| Under 45 | Age + BP + cholesterol | 0.141 | 1.52 | +0.07 |
| 45 to 55 | Age alone | 0.247 | 0.62 | -0.00 |
| 45 to 55 | Age + BP + cholesterol | 0.194 | 1.02 | -0.01 |
| 56 and over | Age alone | 0.233 | 1.15 | +0.00 |
| 56 and over | Age + BP + cholesterol | 0.203 | 0.76 | +0.02 |
| All women | Age alone | 0.235 | 0.96 | +0.00 |
| All women | Age + BP + cholesterol | 0.190 | 0.96 | +0.01 |

## Sensitivity analyses: gain in AUC by age group

Each row repeats the whole pipeline (split, fit, bootstrap) with one decision changed. Cleaning variants change which records exist, so they also re-draw the split.

| Analysis | Records | Under 45 | 45 to 55 | 56 and over |
|---|---:|---|---|---|
| Primary analysis | 44,727 | +0.255 (0.213 to 0.299) | +0.216 (0.196 to 0.235) | +0.158 (0.137 to 0.180) |
| Flexible curves for age and blood pressure | 44,727 | +0.256 (0.215 to 0.299) | +0.217 (0.197 to 0.237) | +0.160 (0.141 to 0.184) |
| Stricter blood pressure range | 44,619 | +0.240 (0.198 to 0.287) | +0.223 (0.205 to 0.244) | +0.141 (0.120 to 0.165) |
| Looser blood pressure range | 44,744 | +0.262 (0.220 to 0.306) | +0.220 (0.199 to 0.238) | +0.151 (0.129 to 0.173) |
| Typing errors repaired, not removed | 45,477 | +0.239 (0.195 to 0.278) | +0.218 (0.200 to 0.236) | +0.148 (0.127 to 0.168) |
| Repeated rows removed | 44,706 | +0.261 (0.218 to 0.303) | +0.219 (0.201 to 0.237) | +0.148 (0.123 to 0.170) |
| Implausible height or weight removed | 44,690 | +0.221 (0.181 to 0.268) | +0.218 (0.198 to 0.235) | +0.160 (0.139 to 0.182) |
| Cross-validation, all records (20 x 5-fold) | 44,727 | +0.244 (0.244 to 0.244) | +0.227 (0.226 to 0.227) | +0.147 (0.147 to 0.147) |

For the cross-validation row the bracket is the range across repeats, not a confidence interval.

## Alternative age bands (same models, same test set)

| Scheme | Band | Test records | AUC, age alone | AUC, expanded | Gain (95% CI) |
|---|---|---:|---:|---:|---|
| Five-year bands | Under 45 | 1,253 | 0.555 | 0.811 | +0.255 (0.212 to 0.300) |
| Five-year bands | 45 to 49 | 1,394 | 0.486 | 0.769 | +0.283 (0.244 to 0.315) |
| Five-year bands | 50 to 54 | 2,237 | 0.557 | 0.757 | +0.200 (0.169 to 0.230) |
| Five-year bands | 55 to 59 | 2,473 | 0.524 | 0.735 | +0.210 (0.184 to 0.238) |
| Five-year bands | 60 to 64 | 1,589 | 0.549 | 0.696 | +0.147 (0.111 to 0.180) |
| Equal-sized thirds | Youngest third (under 50.5) | 2,959 | 0.563 | 0.794 | +0.231 (0.208 to 0.253) |
| Equal-sized thirds | Middle third (50.5 to 57.3) | 2,990 | 0.557 | 0.756 | +0.199 (0.175 to 0.223) |
| Equal-sized thirds | Oldest third (57.3 and over) | 2,997 | 0.565 | 0.714 | +0.149 (0.124 to 0.173) |

## Exploratory: which measurement carries the gain?

| Model | Type | Under 45 | 45 to 55 | 56 and over | All women |
|---|---|---|---|---|---|
| Age + systolic BP | exploratory | 0.802 (+0.246) | 0.748 (+0.201) | 0.709 (+0.145) | 0.772 (+0.130) |
| Age + cholesterol | exploratory | 0.600 (+0.045) | 0.605 (+0.059) | 0.621 (+0.057) | 0.676 (+0.033) |
| Age + systolic BP + cholesterol (primary) | primary | 0.811 (+0.255) | 0.762 (+0.216) | 0.722 (+0.158) | 0.783 (+0.140) |
| Age + everything recorded | exploratory | 0.815 (+0.260) | 0.767 (+0.221) | 0.723 (+0.159) | 0.785 (+0.142) |

Cells show held-out AUC and, in brackets, the gain over age alone.

## Adjusted associations (odds ratios, 95% CI)

| Cohort | Term | Odds ratio (95% CI) |
|---|---|---|
| All women | Cholesterol above normal (vs normal) | 1.46 (1.37 to 1.56) |
| All women | Cholesterol well above normal (vs normal) | 2.71 (2.52 to 2.91) |
| All women | Age, per 5 years | 1.32 (1.30 to 1.34) |
| All women | Systolic BP, per 10 mmHg | 1.86 (1.83 to 1.89) |
| Under 45 | Cholesterol above normal (vs normal) | 2.65 (2.19 to 3.21) |
| Under 45 | Cholesterol well above normal (vs normal) | 5.01 (3.72 to 6.75) |
| Under 45 | Age, per 5 years | 2.09 (1.71 to 2.56) |
| Under 45 | Systolic BP, per 10 mmHg | 2.51 (2.37 to 2.66) |
| 45 to 55 | Cholesterol above normal (vs normal) | 1.50 (1.37 to 1.64) |
| 45 to 55 | Cholesterol well above normal (vs normal) | 3.03 (2.71 to 3.39) |
| 45 to 55 | Age, per 5 years | 1.16 (1.10 to 1.22) |
| 45 to 55 | Systolic BP, per 10 mmHg | 1.99 (1.94 to 2.04) |
| 56 and over | Cholesterol above normal (vs normal) | 1.23 (1.12 to 1.35) |
| 56 and over | Cholesterol well above normal (vs normal) | 2.29 (2.07 to 2.52) |
| 56 and over | Age, per 5 years | 1.64 (1.53 to 1.75) |
| 56 and over | Systolic BP, per 10 mmHg | 1.60 (1.56 to 1.64) |

Likelihood-ratio tests for a difference across age groups: systolic blood pressure chi-square = 294.0 on 2 df (p = 1e-64); cholesterol chi-square = 89.4 on 4 df (p = 2e-18). The by-age-group odds ratios are exploratory.

## Exploratory: CVD-positive records the expanded model scores low

Low-scored means a score in the lowest quarter of the held-out cohort (at or below 0.302). This is a description of model errors, not a diagnostic threshold, and these records are not 'missed diagnoses'.

| Age group | CVD-positive test records | Low-scored | Share (95% CI) |
|---|---:|---:|---|
| Under 45 | 349 | 129 | 37.0% (32.1 to 42.1) |
| 45 to 55 | 1,897 | 249 | 13.1% (11.7 to 14.7) |
| 56 and over | 2,157 | 60 | 2.8% (2.2 to 3.6) |

Share of all CVD-positive records in the cleaned cohort with systolic blood pressure under 130 mmHg and normal cholesterol:

| Age group | CVD-positive records | Under 130 mmHg and normal cholesterol | Share (95% CI) |
|---|---:|---:|---|
| Under 45 | 1,743 | 545 | 31.3% (29.1 to 33.5) |
| 45 to 55 | 9,485 | 2,820 | 29.7% (28.8 to 30.7) |
| 56 and over | 10,783 | 2,954 | 27.4% (26.6 to 28.2) |

## Context

Systolic blood pressure rises 5.8 mmHg per 10 years of age (95% CI 5.6 to 6.1); R² = 0.054.

## Limits on interpretation

- The outcome is a CVD label recorded at the same exam as the measurements. Nothing here predicts future disease.
- The source does not document how the label was assigned. If it reflects diagnoses that include high blood pressure itself, blood pressure is partly measuring the outcome.
- Associations are not causal effects. Age groups are age bands, not menopause stages.
- The bootstrap intervals describe uncertainty from the test sample. They do not cover how the records were collected, which the source does not describe.
- Sex is recorded as one binary code. The cohort is a convenience sample, not a sample of any population of women.
